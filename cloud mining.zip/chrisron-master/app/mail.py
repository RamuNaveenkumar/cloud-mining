from django.core.mail import send_mail

send_mail("Subject","messgae","abishek.vp13@gmail.com","abishekarmy2003@gmail.com")
